figapp
======

Sample Python application for testing Fig in The Docker Book.
