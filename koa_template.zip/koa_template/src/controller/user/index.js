let str = 'emicent_koa2_template:v0.1'

module.exports = {
    async get(ctx) {
        ctx.type = 'text/html; charset=utf-8'
        ctx.response.body = `<h1 style='text-align:center'>${str}</h1>`
    }
}
