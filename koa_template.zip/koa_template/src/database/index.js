let { DB_CONFIG } = require('../config')
const db = { DB_CONFIG }
module.exports = {
    db
}
