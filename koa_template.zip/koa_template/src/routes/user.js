const router = require('koa-router')()
const user = require('../controller/user/index')

router.prefix(process.env.baseUri ? process.env.baseUri : '/') //请求前缀

router.get('/', user.get)

module.exports = router
