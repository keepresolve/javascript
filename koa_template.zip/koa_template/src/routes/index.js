const router = require('koa-router')()
const user = require('./user')
let { errorCode } = require('../config')

//https://cnodejs.org/topic/5b13c12157137f22415c4892 koa-router详细解释
// 错误统一处理  throw 并返回
const errHandler = async (ctx, next) => {
    //response.status default 404, check https://koajs.com/#response
    //response.body 一旦设置就改为200
    try {
        ctx.response.set('Access-Control-Allow-Origin', '*')
        await next()
    } catch (err) {
        if (err.hasOwnProperty('custom')) {
            err.info = err.info ? err.info : errorCode(err.status)
            delete err.custom
            logger.debug('emit custom error')
            ctx.response.body = err
        } else {
            ctx.response.status = err.statusCode || err.status || 500
            ctx.response.body = { status: 99999, info: err.message }
            logger.debug(`emit system error`)
        }
        ctx.app.emit('error', err, ctx)
    }
}

router.use(errHandler) //错误处理
router.use(user.routes()) //分类处理路由
module.exports = router
