window.onload = function() {
    let btn = document.getElementById('btn')
    async function test() {
        try {
            let result = await fetch(
                'http://118.212.149.43:1046/Api/Client/getinfo?un=1005&pwd=e10adc3949ba59abbe56e057f20f883e&cFlag=1&eid=1033'
            )
            let result2 = await result.json()
            console.log('a', result, result2)
        } catch (error) {
            console.log(error)
        }
    }
    btn.onclick = function() {
        test()
    }
}
